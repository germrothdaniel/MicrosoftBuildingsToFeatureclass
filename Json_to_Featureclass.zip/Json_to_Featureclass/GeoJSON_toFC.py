#-------------------------------------------------------------------------------
# Name:        GeoJSON_toFC
# Purpose:     Convert microsoft USBuildingFootprints to a usuable GIS format
#
# Author:      Daniel Germroth
#
# Created:     02/07/2018
# Copyright:   (c) Daniel Germroth 2018
# Licence:     Apache-2.0
#-------------------------------------------------------------------------------


import json
import arcpy
import os
import time

# Function prints messages in python interpreter as well as in the arc suite console
def Print(string_to_print):
    arcpy.AddMessage(string_to_print)
    print string_to_print

Print("Script executed at " + time.strftime("%Y-%m-%d %H:%M:%S"))


# User Parameters
input_json = arcpy.GetParameterAsText(0)
sr_ouput = arcpy.GetParameterAsText(1)
output_gdb = arcpy.GetParameterAsText(2)
output_fc_name = arcpy.GetParameterAsText(3)



sr_in = arcpy.SpatialReference(4326)


# Function deletes output featurelcass if it exists or creates an empty one
def Create_FC(output_gdb, output_fc_name, sr_ouput):
    Print("Creating empty featureClass at given location")

    out_fc_fullPath = os.path.join(output_gdb, output_fc_name)

    if arcpy.Exists(out_fc_fullPath):
        arcpy.Delete_management(out_fc_fullPath)

    else:
        arcpy.CreateFeatureclass_management(output_gdb, output_fc_name, spatial_reference=sr_ouput)

    return out_fc_fullPath

out_fc_fullPath = Create_FC(output_gdb, output_fc_name, sr_ouput)


with open(input_json) as infile:
    json_raw_dataDict = json.load(infile)


# Function creates arcpy polygon object from json data
def Json_to_Poly(geoJson_dict):
    # Create empty list to which polygons will be appended as they are processed
    poly_list_out = []

    # Set up variables to be used in printing progress reports
    n = 0
    k = 10000

    # Retrieve dictionary of features from raw json data dicitonary
    features = geoJson_dict['features']
    Print("There are " + str(len(features)) + " that will be processed into polygons")

    # iterate through features in dictionary of jSON data
    for feature in features:

        # Report Progress to user
        n += 1
        if n % k == 0:
            Print(str(n) + " json features have been converted to polygons " + time.strftime("%Y-%m-%d %H:%M:%S"))

        # Travel down the nested dict wormhole to retrieve the list of coordinates
        ftr_xy_list = feature['geometry']['coordinates'][0]

##        return ftr_xy_list

        # Create polygon object from coordinate list
        poly = arcpy.Polygon(arcpy.Array([arcpy.Point(coords[0], coords[1]) for coords in ftr_xy_list]), sr_in)

        # Project polygon to user-provided coordinate system
        poly_out = poly.projectAs(sr_ouput)

        poly_list_out.append(poly_out)

    return poly_list_out


polys_list = Json_to_Poly(json_raw_dataDict)



# Function inserts polygon objects into new featureclass
def Insert_Polys():
    # Set up variables to be used in printing progress reports
    n = 0
    k = 10000

    with arcpy.da.InsertCursor(out_fc_fullPath, 'SHAPE@') as iCur:
        for poly in polys_list:
            iCur.insertRow([poly])

            # Report Progress to user
            n += 1
            if n % k == 0:
                Print(str(n) + " polygons have been written to output featureclass " + time.strftime("%Y-%m-%d %H:%M:%S"))

Insert_Polys()

Print("Script Complete at " + time.strftime("%Y-%m-%d %H:%M:%S"))




